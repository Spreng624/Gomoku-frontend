#ifndef MANAGER_H
#define MANAGER_H

#include <QObject>
#include <QThread>
#include <QMainWindow>
#include <QStackedWidget>
#include <QMessageBox>
#include <memory>
#include <string>
#include <map>
#include <functional>

// 前向声明
class LobbyWidget;
class GameWidget;
class Client;
class Packet;
class QStatusBar;
class QTimer;
class Server;

class Manager : public QObject
{
    Q_OBJECT

public:
    explicit Manager(QObject *parent = nullptr);
    ~Manager();

    void startClientThread();
    void stopClientThread();

    void connectToServer();
    void disconnectFromServer();
    bool isConnected() const;

    void setMainWindow(QMainWindow *mainWindow);
    void setStackedWidget(QStackedWidget *stackedWidget);
    void setStatusBar(QStatusBar *statusBar);
    void setLobbyWidget(LobbyWidget *lobby);
    void setGameWidget(GameWidget *game);
    void setPacketCallback(std::function<void(const Packet &)> handler);

    void login(const std::string &username, const std::string &password);
    void loginAsGuest();
    void logout();

    void createRoom(const std::string &roomName, int boardSize = 15, int timeLimit = 1200);
    void joinRoom(uint32_t roomId);
    void quickMatch();
    void exitRoom();

    // 游戏操作
    void makeMove(int x, int y);
    void requestUndo();
    void requestDraw();
    void respondDraw(bool accept);
    void giveUp();

    // 查询操作
    void refreshRoomList();
    void refreshPlayerList();
    void sendPacket(const Packet &packet);

signals:

    void onSwitchWidget(int index);

    // 连接状态
    void connectionStatusChanged(bool connected);
    void connectionError(const QString &error);

    // 用户相关
    void loginSuccess(const QString &username, int rating);
    void loginFailed(const QString &reason);
    void guestLoginSuccess(const QString &guestId, int rating);

    // 房间相关
    void roomCreated(uint32_t roomId, const QString &roomName);
    void roomJoined(uint32_t roomId, const QString &opponentName, int opponentRating, bool isBlack);
    void roomListUpdated(const QList<QPair<uint32_t, QString>> &rooms);
    void playerListUpdated(const QList<QPair<QString, int>> &players);
    void playerJoined(const QString &playerName, int rating);
    void playerLeft(const QString &playerName);

    // 游戏相关
    void gameStarted(bool isBlack);
    void opponentMoved(int x, int y);
    void gameEnded(const QString &winner, const QString &reason);
    void drawRequested();
    void giveUpRequested();

    // 聊天相关
    void chatMessageReceived(const QString &sender, const QString &message);

    // 向后兼容的信号
    void localGameRequested();
    void onlineGameRequested();
    void sendInitRequest();

public slots:
    void handlePacket(const Packet &packet);
    void onLocalGameClicked();
    void onOnlineGameClicked();

private slots:
    void onClientThreadFinished();

private:
    // 请求ID管理
    uint64_t generateRequestId();
    void registerCallback(uint64_t requestId, std::function<void(const Packet &)> callback);

    // 初始化
    void initializeConnection();
    void setupSignalConnections();

    // 界面管理方法
    void updateStatusBar(const QString &message);
    void switchToLobby();
    void switchToGame();
    void setWindowTitle(const QString &title);
    void showMessageBox(const QString &title, const QString &message, QMessageBox::Icon icon = QMessageBox::Information);
    void showQuestionBox(const QString &title, const QString &message, std::function<void(bool)> callback);
    void scheduleReturnToLobby(int delayMs = 2000);

    // 成员变量
    QMainWindow *mainWindow;
    QStackedWidget *stackedWidget;
    QStatusBar *statusBar;
    LobbyWidget *lobbyWidget;
    GameWidget *gameWidget;
    std::unique_ptr<Client> client;
    QThread *clientThread;
    QTimer *returnToLobbyTimer;
    std::string serverIp;
    int serverPort;
    bool connected;

    // 请求回调映射
    std::map<uint64_t, std::function<void(const Packet &)>> requestCallbacks;
    uint64_t nextRequestId;

    // 会话状态
    uint64_t sessionId;
    std::string username;
    int rating;
    uint32_t currentRoomId;
    bool inGame;
    QString currentUsername;
    int currentRating;
    std::function<void(const Packet &)> sendPacketCallback;
};

#endif // MANAGER_H
