#include "GameWidget.h"
#include "Manager.h"
#include <QMessageBox>
#include <QTime>
#include <QFont>
#include <QFile>
#include <QTextStream>
#include "Logger.h"

GameWidget::GameWidget(QWidget *parent)
    : QWidget(parent), currentPlayer(true), gameStarted(false),
      isGameOver(false), player1Time(1200), player2Time(1200)
{
    // 设置窗口大小和样式
    setFixedSize(1000, 700);

    // 初始化UI
    initUI();
    initConnections();

    // 初始化计时器
    gameTimer = new QTimer(this);
    connect(gameTimer, &QTimer::timeout, this, &GameWidget::onTimerUpdate);

    // 设置默认玩家信息
    setPlayerInfo("廊郎", 1500, "汐汐", 1520);
    setGameMode(true);

    // 重置游戏状态
    resetGame();
    LOG_INFO("GameWidget initialized");
}

void GameWidget::initUI()
{
    QHBoxLayout *mainLayout = new QHBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    // ========== 左侧棋盘区域 ==========
    chessBoardWidget = new ChessBoardWidget(this);
    chessBoardWidget->setGame(&game);
    mainLayout->addWidget(chessBoardWidget);

    // ========== 右侧面板区域 ==========
    rightPanel = new QWidget(this);
    rightPanel->setObjectName("rightPanel");
    rightPanel->setFixedWidth(300);

    QVBoxLayout *rightLayout = new QVBoxLayout(rightPanel);
    rightLayout->setSpacing(10);
    rightLayout->setContentsMargins(15, 15, 15, 15);

    // 顶部信息栏
    QWidget *topBar = new QWidget();
    QHBoxLayout *topLayout = new QHBoxLayout(topBar);
    topLayout->setContentsMargins(0, 0, 0, 0);

    gameIdLabel = new QLabel("#146 桌");
    gameIdLabel->setObjectName("gameIdLabel");

    timeRuleLabel = new QLabel("20+5 分，19");
    timeRuleLabel->setObjectName("timeRuleLabel");

    QPushButton *minimizeBtn = new QPushButton("─");
    QPushButton *closeBtn = new QPushButton("×");
    minimizeBtn->setFixedSize(25, 25);
    closeBtn->setFixedSize(25, 25);

    topLayout->addWidget(gameIdLabel);
    topLayout->addStretch();
    topLayout->addWidget(timeRuleLabel);
    topLayout->addWidget(minimizeBtn);
    topLayout->addWidget(closeBtn);

    rightLayout->addWidget(topBar);

    // 玩家信息区域
    QWidget *playersWidget = new QWidget();
    QVBoxLayout *playersLayout = new QVBoxLayout(playersWidget);
    playersLayout->setSpacing(10);

    // 玩家1
    player1Widget = new QWidget();
    player1Widget->setObjectName("player1Widget");
    QHBoxLayout *p1Layout = new QHBoxLayout(player1Widget);

    player1Avatar = new QPushButton("P1");
    player1Avatar->setObjectName("player1Avatar");
    player1Avatar->setFixedSize(40, 40);

    QVBoxLayout *p1InfoLayout = new QVBoxLayout();
    player1NameLabel = new QLabel("張三");
    player1NameLabel->setObjectName("player1NameLabel");
    player1ScoreLabel = new QLabel("等級分: 1500");
    player1ScoreLabel->setObjectName("player1ScoreLabel");
    player1TimeLabel = new QLabel("20:00");
    player1TimeLabel->setObjectName("player1TimeLabel");

    p1InfoLayout->addWidget(player1NameLabel);
    p1InfoLayout->addWidget(player1ScoreLabel);
    p1InfoLayout->addWidget(player1TimeLabel);
    p1InfoLayout->setSpacing(2);

    p1Layout->addWidget(player1Avatar);
    p1Layout->addLayout(p1InfoLayout);

    // 玩家2
    player2Widget = new QWidget();
    player2Widget->setObjectName("player2Widget");
    QHBoxLayout *p2Layout = new QHBoxLayout(player2Widget);

    player2Avatar = new QPushButton("P2");
    player2Avatar->setObjectName("player2Avatar");
    player2Avatar->setFixedSize(40, 40);

    QVBoxLayout *p2InfoLayout = new QVBoxLayout();
    player2NameLabel = new QLabel("李四");
    player2NameLabel->setObjectName("player2NameLabel");
    player2ScoreLabel = new QLabel("等級分: 1520");
    player2ScoreLabel->setObjectName("player2ScoreLabel");
    player2TimeLabel = new QLabel("20:00");
    player2TimeLabel->setObjectName("player2TimeLabel");

    p2InfoLayout->addWidget(player2NameLabel);
    p2InfoLayout->addWidget(player2ScoreLabel);
    p2InfoLayout->addWidget(player2TimeLabel);
    p2InfoLayout->setSpacing(2);

    p2Layout->addWidget(player2Avatar);
    p2Layout->addLayout(p2InfoLayout);

    playersLayout->addWidget(player1Widget);
    playersLayout->addWidget(player2Widget);

    rightLayout->addWidget(playersWidget);

    // 控制按钮
    QWidget *controlWidget = new QWidget();
    QHBoxLayout *controlLayout = new QHBoxLayout(controlWidget);
    controlLayout->setContentsMargins(0, 0, 0, 0);

    surrenderButton = new QPushButton("認輸");
    undoButton = new QPushButton("悔棋");

    surrenderButton->setFixedHeight(40);
    undoButton->setFixedHeight(40);

    controlLayout->addWidget(surrenderButton);
    controlLayout->addWidget(undoButton);

    rightLayout->addWidget(controlWidget);

    // 选项卡区域
    tabWidget = new QTabWidget();
    tabWidget->setTabPosition(QTabWidget::South);

    // 聊天页
    chatTab = new QWidget();
    QVBoxLayout *chatLayout = new QVBoxLayout(chatTab);

    chatHistory = new QTextEdit();
    chatHistory->setReadOnly(true);
    chatHistory->setFixedHeight(250);

    QHBoxLayout *inputLayout = new QHBoxLayout();
    messageInput = new QLineEdit();
    sendButton = new QPushButton("發送");

    inputLayout->addWidget(messageInput);
    inputLayout->addWidget(sendButton);

    chatLayout->addWidget(chatHistory);
    chatLayout->addLayout(inputLayout);

    tabWidget->addTab(chatTab, "聊天");

    // 记录页
    recordTab = new QWidget();
    QVBoxLayout *recordLayout = new QVBoxLayout(recordTab);

    moveList = new QListWidget();
    recordLayout->addWidget(moveList);

    tabWidget->addTab(recordTab, "記錄");

    // 玩家页
    playerTab = new QWidget();
    QVBoxLayout *playerLayout = new QVBoxLayout(playerTab);

    onlinePlayers = new QListWidget();
    playerLayout->addWidget(onlinePlayers);

    tabWidget->addTab(playerTab, "玩家");

    // 设置页
    settingTab = new QWidget();
    QVBoxLayout *settingLayout = new QVBoxLayout(settingTab);
    settingLayout->setAlignment(Qt::AlignTop);

    soundToggle = new QPushButton("音效: 開");
    bgmToggle = new QPushButton("背景音樂: 關");
    autoSaveToggle = new QPushButton("自動保存: 開");

    soundToggle->setCheckable(true);
    bgmToggle->setCheckable(true);
    autoSaveToggle->setCheckable(true);

    soundToggle->setChecked(true);
    bgmToggle->setChecked(false);
    autoSaveToggle->setChecked(true);

    settingLayout->addWidget(soundToggle);
    settingLayout->addWidget(bgmToggle);
    settingLayout->addWidget(autoSaveToggle);

    tabWidget->addTab(settingTab, "設置");

    rightLayout->addWidget(tabWidget, 1);

    // 底部按钮
    QWidget *bottomWidget = new QWidget();
    QHBoxLayout *bottomLayout = new QHBoxLayout(bottomWidget);
    bottomLayout->setContentsMargins(0, 0, 0, 0);

    backToLobbyButton = new QPushButton("返回大廳");
    restartButton = new QPushButton("重新開始");

    bottomLayout->addWidget(backToLobbyButton);
    bottomLayout->addWidget(restartButton);

    rightLayout->addWidget(bottomWidget);

    mainLayout->addWidget(rightPanel);

    // 加载QSS样式表
    QFile qssFile(":/styles/gamewidget.qss");
    if (!qssFile.exists())
    {
        qssFile.setFileName("src/gamewidget.qss");
    }
    if (qssFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream stream(&qssFile);
        QString styleSheet = stream.readAll();
        rightPanel->setStyleSheet(styleSheet);
        qssFile.close();
    }
    else
    {
        LOG_ERROR("Failed to load gamewidget.qss");
    }

    // 添加示例聊天记录
    addChatMessage("系統", "對局開始！黑方先行。");
    addChatMessage("張三", "大家好！");
    addChatMessage("李四", "請多指教。");

    // 添加示例在线玩家
    onlinePlayers->addItem("張三 (對戰中)");
    onlinePlayers->addItem("李四 (對戰中)");
    onlinePlayers->addItem("王五 (在線)");
    onlinePlayers->addItem("趙六 (忙碌)");
    onlinePlayers->addItem("陳七 (在線)");
}

void GameWidget::initConnections()
{
    connect(surrenderButton, &QPushButton::clicked, this, &GameWidget::onSurrenderClicked);
    connect(undoButton, &QPushButton::clicked, this, &GameWidget::onUndoClicked);
    connect(sendButton, &QPushButton::clicked, this, &GameWidget::onSendMessage);
    connect(messageInput, &QLineEdit::returnPressed, this, &GameWidget::onSendMessage);
    connect(backToLobbyButton, &QPushButton::clicked, this, &GameWidget::backToLobby);
    connect(restartButton, &QPushButton::clicked, this, [this]()
            { resetGame(); });

    // 连接棋盘部件的信号
    connect(chessBoardWidget, &ChessBoardWidget::moveMade, this, &GameWidget::onChessBoardMoveMade);
}

void GameWidget::resetGame()
{
    game.reset();
    currentPlayer = true; // 黑棋先行
    gameStarted = true;
    isGameOver = false;
    winner.clear();

    player1Time = 1200; // 20分钟
    player2Time = 1200;

    player1TimeLabel->setText("20:00");
    player2TimeLabel->setText("20:00");

    moveList->clear();
    addChatMessage("系統", "新對局開始！黑方先行。");

    // 重要：先更新棋盘状态
    chessBoardWidget->resetGame();
    chessBoardWidget->setCurrentPlayer(currentPlayer);

    // 重要：先重置玩家指示器，然后设置黑棋为当前玩家
    player1Widget->setProperty("currentPlayer", false);
    player2Widget->setProperty("currentPlayer", false);
    player1Widget->style()->unpolish(player1Widget);
    player1Widget->style()->polish(player1Widget);
    player2Widget->style()->unpolish(player2Widget);
    player2Widget->style()->polish(player2Widget);

    // 再设置黑棋为当前玩家
    if (currentPlayer)
    { // 黑棋回合
        player1Widget->setProperty("currentPlayer", true);
        player1Widget->style()->unpolish(player1Widget);
        player1Widget->style()->polish(player1Widget);
    }
    else
    {
        player2Widget->setProperty("currentPlayer", true);
        player2Widget->style()->unpolish(player2Widget);
        player2Widget->style()->polish(player2Widget);
    }

    // 启动计时器
    if (!gameTimer->isActive())
    {
        gameTimer->start(1000); // 每秒更新一次
    }
}

void GameWidget::setPlayerInfo(const QString &player1Name, int player1Score,
                               const QString &player2Name, int player2Score)
{
    player1NameLabel->setText(player1Name);
    player1ScoreLabel->setText(QString("等級分: %1").arg(player1Score));

    player2NameLabel->setText(player2Name);
    player2ScoreLabel->setText(QString("等級分: %1").arg(player2Score));
}

void GameWidget::setGameMode(bool isPvP)
{
    Q_UNUSED(isPvP);
}

void GameWidget::onSurrenderClicked()
{
    if (!gameStarted)
        return;

    QString surrenderingPlayer = currentPlayer ? player1NameLabel->text() : player2NameLabel->text();
    QString winningPlayer = currentPlayer ? player2NameLabel->text() : player1NameLabel->text();

    int ret = QMessageBox::question(this, "確認認輸",
                                    QString("%1 確定要認輸嗎？").arg(surrenderingPlayer),
                                    QMessageBox::Yes | QMessageBox::No);

    if (ret == QMessageBox::Yes)
    {
        isGameOver = true;
        winner = winningPlayer;
        gameTimer->stop();

        QString message = QString("%1 認輸，%2 獲勝！").arg(surrenderingPlayer).arg(winningPlayer);
        addChatMessage("系統", message);

        chessBoardWidget->setGameOver(true, winner);

        showWinDialog(winner);
    }
}

void GameWidget::onUndoClicked()
{
    if (!gameStarted || game.isBoardFull())
        return;

    int ret = QMessageBox::question(this, "請求悔棋",
                                    "請求悔棋一步，對方是否同意？",
                                    QMessageBox::Yes | QMessageBox::No);

    if (ret == QMessageBox::Yes)
    {
        // 这里需要实现悔棋逻辑
        addChatMessage("系統", QString("%1 悔棋一步").arg(currentPlayer ? player2NameLabel->text() : player1NameLabel->text()));

        // 简单示例：切换玩家
        switchPlayer();
    }
}

void GameWidget::onSendMessage()
{
    QString message = messageInput->text().trimmed();
    if (!message.isEmpty())
    {
        QString currentPlayerName = currentPlayer ? player1NameLabel->text() : player2NameLabel->text();
        addChatMessage(currentPlayerName, message);
        messageInput->clear();
    }
}

void GameWidget::onTimerUpdate()
{
    if (currentPlayer)
    {
        player1Time--;
        if (player1Time <= 0)
        {
            player1Time = 0;
            isGameOver = true;
            winner = player2NameLabel->text();
            gameTimer->stop();

            QString message = QString("%1 時間到，%2 獲勝！").arg(player1NameLabel->text()).arg(winner);
            addChatMessage("系統", message);

            chessBoardWidget->setGameOver(true, winner);

            showWinDialog(winner);
            return;
        }
    }
    else
    {
        player2Time--;
        if (player2Time <= 0)
        {
            player2Time = 0;
            isGameOver = true;
            winner = player1NameLabel->text();
            gameTimer->stop();

            QString message = QString("%1 時間到，%2 獲勝！").arg(player2NameLabel->text()).arg(winner);
            addChatMessage("系統", message);

            chessBoardWidget->setGameOver(true, winner);

            showWinDialog(winner);
            return;
        }
    }

    // 更新时间显示
    player1TimeLabel->setText(QString("%1:%2")
                                  .arg(player1Time / 60, 2, 10, QChar('0'))
                                  .arg(player1Time % 60, 2, 10, QChar('0')));

    player2TimeLabel->setText(QString("%1:%2")
                                  .arg(player2Time / 60, 2, 10, QChar('0'))
                                  .arg(player2Time % 60, 2, 10, QChar('0')));
}

void GameWidget::onChessBoardMoveMade(int x, int y)
{
    if (isGameOver)
        return;

    Piece playerPiece = currentPlayer ? Piece::BLACK : Piece::WHITE;

    if (game.makeMove(x, y, playerPiece))
    {
        // 记录这一步
        addMoveRecord(x, y, currentPlayer);

        // 检查是否获胜
        if (game.checkWin(x, y, playerPiece))
        {
            isGameOver = true;
            winner = currentPlayer ? player1NameLabel->text() : player2NameLabel->text();
            gameTimer->stop();

            QString winMessage = QString("%1 獲得勝利！").arg(winner);
            addChatMessage("系統", winMessage);

            chessBoardWidget->setGameOver(true, winner);

            showWinDialog(winner);
            return;
        }

        // 检查是否平局
        if (game.isBoardFull())
        {
            isGameOver = true;
            winner = "平局";
            gameTimer->stop();

            addChatMessage("系統", "棋盤已滿，平局！");

            chessBoardWidget->setGameOver(true, winner);

            QMessageBox::information(this, "遊戲結束", "平局！");
            return;
        }

        // 切换玩家
        switchPlayer();

        // 更新棋盘显示
        chessBoardWidget->setCurrentPlayer(currentPlayer);

        // 添加聊天消息
        QString playerName = currentPlayer ? player2NameLabel->text() : player1NameLabel->text();
        QString pieceColor = currentPlayer ? "白" : "黑";
        addChatMessage("系統",
                       QString("%1 在 (%2, %3) 落子").arg(playerName).arg(x + 1).arg(y + 1));
    }
}

void GameWidget::switchPlayer()
{
    currentPlayer = !currentPlayer;

    // 更新玩家指示器样式
    if (currentPlayer)
    {
        player1Widget->setProperty("currentPlayer", true);
        player2Widget->setProperty("currentPlayer", false);
    }
    else
    {
        player1Widget->setProperty("currentPlayer", false);
        player2Widget->setProperty("currentPlayer", true);
    }
    // 强制样式更新
    player1Widget->style()->unpolish(player1Widget);
    player1Widget->style()->polish(player1Widget);
    player2Widget->style()->unpolish(player2Widget);
    player2Widget->style()->polish(player2Widget);
}

void GameWidget::updateGameStatus()
{
    // 更新游戏状态显示
}

void GameWidget::showWinDialog(const QString &winner)
{
    QMessageBox msgBox(this);
    msgBox.setWindowTitle("遊戲結束");
    msgBox.setText(QString("%1 獲勝！").arg(winner));
    msgBox.setIcon(QMessageBox::Information);

    QPushButton *restartBtn = msgBox.addButton("重新開始", QMessageBox::AcceptRole);
    QPushButton *lobbyBtn = msgBox.addButton("返回大廳", QMessageBox::RejectRole);

    msgBox.exec();

    if (msgBox.clickedButton() == restartBtn)
    {
        resetGame();
    }
    else if (msgBox.clickedButton() == lobbyBtn)
    {
        emit backToLobby();
    }
}

void GameWidget::addMoveRecord(int row, int col, bool isBlack)
{
    QString moveText = QString("%1. %2 (%3, %4)")
                           .arg(moveList->count() + 1, 2)
                           .arg(isBlack ? "黑" : "白")
                           .arg(col + 1)
                           .arg(row + 1);

    moveList->addItem(moveText);
    moveList->scrollToBottom();
}

void GameWidget::addChatMessage(const QString &player, const QString &message)
{
    QString timestamp = QTime::currentTime().toString("hh:mm");
    QString fullMessage = QString("[%1] %2: %3").arg(timestamp).arg(player).arg(message);

    chatHistory->append(fullMessage);
    chatHistory->moveCursor(QTextCursor::End);
}
