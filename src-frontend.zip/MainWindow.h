#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <memory>
#include "LobbyWidget.h"
#include "GameWidget.h"
#include "Manager.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onSwitchWidget(int index);

private:
    void initStyle();

    void initTitleBar();
    void initStatusBar();
    void initLayout();
    void updateWindowTitle(const QString &title);

    void setStatusMessage(const QString &message);
    void setNetworkStatus(bool connected);
    void setUserInfo(const QString &username, int rating);

    // 自定义标题栏组件
    QWidget *titleBarWidget;
    QLabel *titleLabel;
    QPushButton *minimizeButton;
    QPushButton *maximizeButton;
    QPushButton *closeButton;

    // 自定义状态栏组件
    QWidget *statusBarWidget;
    QLabel *statusMessageLabel;
    QLabel *networkStatusLabel;
    QLabel *userInfoLabel;

    // 原有成员变量
    QStackedWidget *stackedWidget;
    LobbyWidget *lobby;
    GameWidget *game;
    std::unique_ptr<Manager> manager;
    bool networkConnected;
    QString currentUsername;
    int currentRating;

    // 鼠标拖动相关
    QPoint dragPosition;
    bool maximized;

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseDoubleClickEvent(QMouseEvent *event) override;
};

#endif // MAINWINDOW_H
