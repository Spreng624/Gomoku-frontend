#ifndef LOBBYWIDGET_H
#define LOBBYWIDGET_H

#include <QWidget>
#include <QResizeEvent>

namespace Ui
{
    class LobbyWidget;
}

class LobbyWidget : public QWidget
{
    Q_OBJECT

public:
    explicit LobbyWidget(QWidget *parent = nullptr);
    ~LobbyWidget();

signals:
    void startLocalGame();
    void startOnlineGame();
    void createNewRoom();
    void joinRoom(int roomId);
    void initRequested();

public slots:
    void updatePlayerList(const QStringList &players);
    void updateRoomList(const QStringList &rooms);

protected:
    void resizeEvent(QResizeEvent *event) override;

private:
    Ui::LobbyWidget *ui;

    void initStyle();
    void initRoomTable();
    void initPlayerList();
};

#endif // LOBBYWIDGET_H
