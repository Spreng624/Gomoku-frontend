#include "Manager.h"
#include "LobbyWidget.h"
#include "GameWidget.h"
#include "Client.h"
#include "Packet.h"
#include "Logger.h"
#include <QDebug>
#include <QThread>
#include <QStatusBar>
#include <QTimer>
#include <functional>
#include <chrono>
#include <random>

// // 辅助函数：生成随机请求ID
// static uint64_t generateRandomId()
// {
//     static std::random_device rd;
//     static std::mt19937_64 gen(rd());
//     static std::uniform_int_distribution<uint64_t> dis(1, 1ULL << 62);
//     return dis(gen);
// }

Manager::Manager(QObject *parent)
    : QObject(parent),
      mainWindow(nullptr),
      stackedWidget(nullptr),
      statusBar(nullptr),
      lobbyWidget(nullptr),
      gameWidget(nullptr),
      client(nullptr),
      clientThread(nullptr),
      returnToLobbyTimer(nullptr),
      serverIp("127.0.0.1"),
      serverPort(8080),
      connected(false),
      nextRequestId(1),
      sessionId(0),
      rating(0),
      currentRoomId(0),
      inGame(false),
      currentRating(1500)
{
    LOG_INFO("Manager initialized");
    client = std::make_unique<Client>(serverIp, serverPort);
    client->SetPacketCallback([this](const Packet &packet)
                              { handlePacket(packet); });
    setupSignalConnections();
    connectToServer();
    sendPacket(Packet(0, MsgType::LoginByGuest));
}

Manager::~Manager()
{
    disconnectFromServer();
    stopClientThread();
    Logger::shutdown();
}

void Manager::connectToServer()
{
    if (client->IsConnected())
    {
        LOG_WARN("Already connected to server");
        return;
    }
    client->Connect();
}

void Manager::disconnectFromServer()
{
    if (!connected)
        return;

    LOG_INFO("Disconnecting from server");
    if (client)
    {
        client->Disconnect();
    }
    stopClientThread();
    connected = false;
    sessionId = 0;
    currentRoomId = 0;
    inGame = false;

    emit connectionStatusChanged(false);
}

bool Manager::isConnected() const
{
    return connected && client && client->IsConnected();
}

void Manager::setMainWindow(QMainWindow *mainWindow)
{
    this->mainWindow = mainWindow;
}

void Manager::setStackedWidget(QStackedWidget *stackedWidget)
{
    this->stackedWidget = stackedWidget;
}

void Manager::setStatusBar(QStatusBar *statusBar)
{
    this->statusBar = statusBar;
}

void Manager::setLobbyWidget(LobbyWidget *lobby)
{
    lobbyWidget = lobby;
    if (lobbyWidget)
    {
        connect(lobbyWidget, &LobbyWidget::startLocalGame,
                this, &Manager::onLocalGameClicked);
        connect(lobbyWidget, &LobbyWidget::startOnlineGame,
                this, &Manager::onOnlineGameClicked);
        connect(lobbyWidget, &LobbyWidget::createNewRoom,
                this, [this]()
                { createRoom("我的房间"); });
        connect(lobbyWidget, &LobbyWidget::joinRoom,
                this, &Manager::joinRoom);
    }
}

void Manager::setGameWidget(GameWidget *game)
{
    gameWidget = game;
    if (gameWidget)
    {
        // 连接游戏界面的信号
        connect(gameWidget, &GameWidget::backToLobby,
                this, [this]()
                {
                    if (inGame)
                        exitRoom();
                    emit onlineGameRequested(); // 切换回大厅
                });
        // 注意：GameWidget的落子信号需要在游戏开始时连接
    }
}

// 用户操作
void Manager::login(const std::string &username, const std::string &password)
{
    if (!isConnected())
    {
        emit loginFailed("未连接到服务器");
        return;
    }

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::Login, requestId);
    packet.AddParam("username", username);
    packet.AddParam("password", password);

    registerCallback(requestId, [this, username](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            this->username = username;
            this->rating = response.GetParam<int>("rating", 1500);
            LOG_INFO("Login successful: " + username + ", rating: " + std::to_string(rating));
            emit loginSuccess(QString::fromStdString(username), rating);
        } else {
            std::string reason = response.GetParam<std::string>("reason", "未知错误");
            LOG_ERROR("Login failed: " + reason);
            emit loginFailed(QString::fromStdString(reason));
        } });

    sendPacket(packet);
}

void Manager::loginAsGuest()
{
    if (!isConnected())
    {
        emit loginFailed("未连接到服务器");
        return;
    }

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::LoginByGuest, requestId);

    registerCallback(requestId, [this](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            std::string guestId = response.GetParam<std::string>("guest_id", "guest");
            this->username = guestId;
            this->rating = response.GetParam<int>("rating", 1500);
            LOG_INFO("Guest login successful: " + guestId);
            emit guestLoginSuccess(QString::fromStdString(guestId), rating);
        } else {
            std::string reason = response.GetParam<std::string>("reason", "未知错误");
            LOG_ERROR("Guest login failed: " + reason);
            emit loginFailed(QString::fromStdString(reason));
        } });

    sendPacket(packet);
}

void Manager::logout()
{
    if (!isConnected())
        return;

    Packet packet(sessionId, MsgType::LogOut);
    sendPacket(packet);

    username.clear();
    rating = 0;
    currentRoomId = 0;
    inGame = false;
}

// 房间操作
void Manager::createRoom(const std::string &roomName, int boardSize, int timeLimit)
{
    if (!isConnected())
        return;

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::CreateRoom, requestId);
    packet.AddParam("room_name", roomName);
    packet.AddParam("board_size", (uint32_t)boardSize);
    packet.AddParam("time_limit", (uint32_t)timeLimit);

    registerCallback(requestId, [this, roomName](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            uint32_t roomId = response.GetParam<uint32_t>("room_id", 0);
            currentRoomId = roomId;
            LOG_INFO("Room created: " + std::to_string(roomId) + " - " + roomName);
            emit roomCreated(roomId, QString::fromStdString(roomName));
        } });

    sendPacket(packet);
}

void Manager::joinRoom(uint32_t roomId)
{
    if (!isConnected())
        return;

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::JoinRoom, requestId);
    packet.AddParam("room_id", roomId);

    registerCallback(requestId, [this, roomId](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            currentRoomId = roomId;
            std::string opponent = response.GetParam<std::string>("opponent", "");
            int opponentRating = response.GetParam<int>("opponent_rating", 1500);
            bool isBlack = response.GetParam<bool>("is_black", true);
            
            LOG_INFO("Joined room " + std::to_string(roomId) + 
                    ", opponent: " + opponent + 
                    ", isBlack: " + std::to_string(isBlack));
            
            emit roomJoined(roomId, 
                           QString::fromStdString(opponent), 
                           opponentRating, 
                           isBlack);
        } });

    sendPacket(packet);
}

void Manager::quickMatch()
{
    if (!isConnected())
        return;

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::QuickMatch, requestId);

    registerCallback(requestId, [this](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            uint32_t roomId = response.GetParam<uint32_t>("room_id", 0);
            currentRoomId = roomId;
            std::string opponent = response.GetParam<std::string>("opponent", "");
            int opponentRating = response.GetParam<int>("opponent_rating", 1500);
            bool isBlack = response.GetParam<bool>("is_black", true);
            
            LOG_INFO("Quick match found: room " + std::to_string(roomId) + 
                    ", opponent: " + opponent);
            
            emit roomJoined(roomId, 
                           QString::fromStdString(opponent), 
                           opponentRating, 
                           isBlack);
        } });

    sendPacket(packet);
}

void Manager::exitRoom()
{
    if (!isConnected() || currentRoomId == 0)
        return;

    Packet packet(sessionId, MsgType::ExitRoom);
    packet.AddParam("room_id", currentRoomId);
    sendPacket(packet);

    currentRoomId = 0;
    inGame = false;
}

// 游戏操作
void Manager::makeMove(int x, int y)
{
    if (!isConnected() || !inGame)
        return;

    Packet packet(sessionId, MsgType::MakeMove);
    packet.AddParam("room_id", currentRoomId);
    packet.AddParam("x", (uint32_t)x);
    packet.AddParam("y", (uint32_t)y);

    sendPacket(packet);
}

void Manager::requestUndo()
{
    if (!isConnected() || !inGame)
        return;

    Packet packet(sessionId, MsgType::BackMove);
    packet.AddParam("room_id", currentRoomId);
    sendPacket(packet);
}

void Manager::requestDraw()
{
    if (!isConnected() || !inGame)
        return;

    Packet packet(sessionId, MsgType::Draw);
    packet.AddParam("room_id", currentRoomId);
    sendPacket(packet);
}

void Manager::respondDraw(bool accept)
{
    if (!isConnected() || !inGame)
        return;

    // 注意：这里需要根据服务器协议实现
    // 暂时使用Draw消息，添加accept参数
    Packet packet(sessionId, MsgType::Draw);
    packet.AddParam("room_id", currentRoomId);
    packet.AddParam("accept", accept);
    sendPacket(packet);
}

void Manager::giveUp()
{
    if (!isConnected() || !inGame)
        return;

    Packet packet(sessionId, MsgType::GiveUp);
    packet.AddParam("room_id", currentRoomId);
    sendPacket(packet);
}

// 查询操作
void Manager::refreshRoomList()
{
    if (!isConnected())
        return;

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::SubscribeRoomList, requestId);

    registerCallback(requestId, [this](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            // 解析房间列表
            // 注意：这里需要根据服务器返回的数据结构实现
            QList<QPair<uint32_t, QString>> rooms;
            // 临时示例数据
            rooms.append({1, "房间1"});
            rooms.append({2, "房间2"});
            emit roomListUpdated(rooms);
        } });

    sendPacket(packet);
}

void Manager::refreshPlayerList()
{
    if (!isConnected())
        return;

    uint64_t requestId = generateRequestId();
    Packet packet(sessionId, MsgType::SubscribeUserList, requestId);

    registerCallback(requestId, [this](const Packet &response)
                     {
        if (response.msgType == MsgType::Success) {
            // 解析玩家列表
            QList<QPair<QString, int>> players;
            // 临时示例数据
            players.append({"玩家1", 1500});
            players.append({"玩家2", 1520});
            emit playerListUpdated(players);
        } });

    sendPacket(packet);
}

// 向后兼容的槽函数
void Manager::onLocalGameClicked()
{
    LOG_INFO("Local game requested");
    emit localGameRequested();
}

void Manager::onOnlineGameClicked()
{
    LOG_INFO("Online game requested");
    if (!isConnected())
    {
        // 自动连接服务器
        connectToServer();
    }
    emit onlineGameRequested();
}

// 私有方法实现
void Manager::startClientThread()
{
    if (clientThread)
        return;

    clientThread = new QThread(this);

    // 将Client移动到线程中
    // 注意：Client不是QObject，需要特殊处理
    // 这里简化处理，在实际项目中可能需要包装Client

    connect(clientThread, &QThread::finished,
            this, &Manager::onClientThreadFinished);

    clientThread->start();
}

void Manager::stopClientThread()
{
    if (!clientThread)
        return;

    clientThread->quit();
    clientThread->wait();
    delete clientThread;
    clientThread = nullptr;
}

void Manager::onClientThreadFinished()
{
    LOG_INFO("Client thread finished");
    connected = false;
    emit connectionStatusChanged(false);
}

uint64_t Manager::generateRequestId()
{
    return nextRequestId++;
}

void Manager::registerCallback(uint64_t requestId, std::function<void(const Packet &)> callback)
{
    requestCallbacks[requestId] = callback;
}

void Manager::initializeConnection()
{
    // 连接建立后的初始化操作
    LOG_INFO("Connection initialized, session ID: " + std::to_string(sessionId));
    connected = true;
    emit connectionStatusChanged(true);

    // 自动以游客身份登录
    loginAsGuest();
}

// 界面管理方法实现
void Manager::updateStatusBar(const QString &message)
{
    if (statusBar)
    {
        statusBar->showMessage(message);
        LOG_DEBUG_FMT("Status bar: %s", message.toStdString().c_str());
    }
}

void Manager::switchToLobby()
{
    if (stackedWidget)
    {
        stackedWidget->setCurrentIndex(0);
        setWindowTitle("五子棋大厅");
        updateStatusBar("已返回大厅");
    }
}

void Manager::switchToGame()
{
    if (stackedWidget)
    {
        stackedWidget->setCurrentIndex(1);
    }
}

void Manager::setWindowTitle(const QString &title)
{
    if (mainWindow)
    {
        mainWindow->setWindowTitle(title);
    }
}

void Manager::showMessageBox(const QString &title, const QString &message, QMessageBox::Icon icon)
{
    if (mainWindow)
    {
        QMessageBox msgBox(mainWindow);
        msgBox.setWindowTitle(title);
        msgBox.setText(message);
        msgBox.setIcon(icon);
        msgBox.exec();
    }
}

void Manager::showQuestionBox(const QString &title, const QString &message, std::function<void(bool)> callback)
{
    if (mainWindow)
    {
        QMessageBox msgBox(mainWindow);
        msgBox.setWindowTitle(title);
        msgBox.setText(message);
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);

        int ret = msgBox.exec();
        if (callback)
        {
            callback(ret == QMessageBox::Yes);
        }
    }
}

void Manager::scheduleReturnToLobby(int delayMs)
{
    if (!returnToLobbyTimer)
    {
        returnToLobbyTimer = new QTimer(this);
        returnToLobbyTimer->setSingleShot(true);
        connect(returnToLobbyTimer, &QTimer::timeout, this, &Manager::switchToLobby);
    }

    returnToLobbyTimer->start(delayMs);
}

void Manager::setupSignalConnections()
{
    // 连接登录相关信号
    connect(this, &Manager::loginSuccess, this, [this](const QString &username, int rating)
            {
        currentUsername = username;
        currentRating = rating;
        updateStatusBar("欢迎, " + username + " (等级分: " + QString::number(rating) + ")");
        refreshRoomList();
        refreshPlayerList(); });

    connect(this, &Manager::guestLoginSuccess, this, [this](const QString &guestId, int rating)
            {
        currentUsername = guestId;
        currentRating = rating;
        updateStatusBar("游客登录: " + guestId + " (等级分: " + QString::number(rating) + ")");
        refreshRoomList();
        refreshPlayerList(); });

    connect(this, &Manager::loginFailed, this, [this](const QString &reason)
            {
        updateStatusBar("登录失败: " + reason);
        showMessageBox("登录失败", reason, QMessageBox::Warning); });

    // 连接房间相关信号
    connect(this, &Manager::roomCreated, this, [this](uint32_t roomId, const QString &roomName)
            {
        updateStatusBar("房间创建成功: " + roomName + " (#" + QString::number(roomId) + ")");
        showMessageBox("房间创建",
                      "房间创建成功!\n房间号: " + QString::number(roomId) + "\n房间名: " + roomName); });

    connect(this, &Manager::roomJoined, this, [this](uint32_t roomId, const QString &opponentName, int opponentRating, bool isBlack)
            {
        updateStatusBar("已加入房间 #" + QString::number(roomId) + ", 对手: " + opponentName);
        
        // 切换到游戏界面
        if (gameWidget)
        {
            gameWidget->resetGame();
            gameWidget->setPlayerInfo(currentUsername, currentRating, opponentName, opponentRating);
            gameWidget->setGameMode(true); // 在线对战模式
        }
        
        switchToGame();
        setWindowTitle("五子棋 - 线上对战 (房间#" + QString::number(roomId) + ")");
        
        // 通知游戏开始
        emit gameStarted(isBlack);
        updateStatusBar("游戏开始，你是" + QString(isBlack ? "黑方" : "白方")); });

    // 连接游戏相关信号
    connect(this, &Manager::gameEnded, this, [this](const QString &winner, const QString &reason)
            {
        updateStatusBar("游戏结束: " + winner + " " + reason);
        showMessageBox("游戏结束", winner + " " + reason);
        scheduleReturnToLobby(2000); });

    connect(this, &Manager::drawRequested, this, [this]()
            {
        updateStatusBar("对手请求和棋");
        showQuestionBox("和棋请求", "对手请求和棋，是否同意？",
                       [this](bool accept) {
                           respondDraw(accept);
                       }); });

    connect(this, &Manager::giveUpRequested, this, [this]()
            {
        updateStatusBar("对手认输");
        showMessageBox("对手认输", "对手已认输，你获胜了！"); });

    connect(this, &Manager::opponentMoved, this, [this](int x, int y)
            {
        updateStatusBar("对手落子: (" + QString::number(x) + ", " + QString::number(y) + ")");
        // 这里需要通知GameWidget对手落子
        if (gameWidget)
        {
            // gameWidget->onOpponentMove(x, y);
        } });

    // 连接玩家状态信号
    connect(this, &Manager::playerJoined, this, [this](const QString &playerName, int rating)
            { updateStatusBar("玩家加入: " + playerName); });

    connect(this, &Manager::playerLeft, this, [this](const QString &playerName)
            { updateStatusBar("玩家离开: " + playerName); });

    // 连接聊天信号
    connect(this, &Manager::chatMessageReceived, this, [this](const QString &sender, const QString &message)
            {
        // 这里需要将聊天消息传递给当前活动的界面
        if (stackedWidget && stackedWidget->currentIndex() == 1 && gameWidget)
        {
            // gameWidget->addChatMessage(sender, message);
        }
        LOG_DEBUG_FMT("聊天: %s: %s", sender.toStdString().c_str(), message.toStdString().c_str()); });

    // 连接向后兼容的信号
    connect(this, &Manager::localGameRequested, this, [this]()
            {
        switchToGame();
        setWindowTitle("五子棋 - 本地对战");
        updateStatusBar("本地对战模式");
        if (gameWidget)
        {
            gameWidget->resetGame();
        } });

    connect(this, &Manager::onlineGameRequested, this, [this]()
            { switchToLobby(); });
}

void Manager::setPacketCallback(std::function<void(const Packet &)> handler)
{
    sendPacketCallback = handler;
}

void Manager::handlePacket(const Packet &packet)
{
    LOG_DEBUG_FMT("Received packet");
}

void Manager::sendPacket(const Packet &packet)
{
    client->SendPacket(packet);
}