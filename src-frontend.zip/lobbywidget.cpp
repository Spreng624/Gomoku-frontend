#include "LobbyWidget.h"
#include "ui_lobbywidget.h"
#include <QLabel>
#include <QFont>
#include <QHeaderView>
#include <QListWidgetItem>
#include <QResizeEvent>
#include <QPushButton>
#include <QFile>
#include <QTextStream>
#include "Logger.h"

LobbyWidget::LobbyWidget(QWidget *parent) : QWidget(parent), ui(new Ui::LobbyWidget)
{
    ui->setupUi(this);
    initStyle();

    // 初始化表格设置
    initRoomTable();
    initPlayerList();

    // 设置表格属性
    ui->roomTableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->roomTableWidget->verticalHeader()->setDefaultSectionSize(40);
    ui->roomTableWidget->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    ui->roomTableWidget->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    ui->roomTableWidget->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    ui->roomTableWidget->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Fixed);
    ui->roomTableWidget->setColumnWidth(3, 80);

    LOG_INFO("LobbyWidget initialized with UI file");
}

LobbyWidget::~LobbyWidget()
{
    delete ui;
}

void LobbyWidget::updatePlayerList(const QStringList &players)
{
}

void LobbyWidget::updateRoomList(const QStringList &rooms)
{
}

// 初始化界面样式 - GitHub Light风格
void LobbyWidget::initStyle()
{
    // 加载QSS样式表
    QFile qssFile(":/styles/lobbywidget.qss");
    if (!qssFile.exists())
    {
        qssFile.setFileName("src/lobbywidget.qss");
    }
    if (qssFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream stream(&qssFile);
        QString styleSheet = stream.readAll();
        this->setStyleSheet(styleSheet);
        qssFile.close();
    }
    else
    {
        LOG_ERROR("Failed to load lobbywidget.qss");
        // 回退到硬编码样式
        this->setStyleSheet(R"(
            /* GitHub Light风格大厅 */
            QWidget {
                background-color: #ffffff;
                color: #24292f;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
                font-size: 14px;
            }
            
            /* 标题样式 */
            QLabel {
                font-size: 20px;
                font-weight: 600;
                color: #24292f;
            }
            
            /* 按钮样式 */
            QPushButton {
                background-color: #f6f8fa;
                border: 1px solid #d0d7de;
                border-radius: 6px;
                color: #24292f;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #f3f4f6;
                border-color: #d0d7de;
            }
            QPushButton:pressed {
                background-color: #ebecf0;
            }
            QPushButton:disabled {
                background-color: #f6f8fa;
                color: #8c959f;
                border-color: #d0d7de;
            }
            
            /* 下拉框样式 */
            QComboBox {
                background-color: #ffffff;
                border: 1px solid #d0d7de;
                border-radius: 6px;
                padding: 6px 12px;
                min-height: 32px;
            }
            QComboBox:hover {
                border-color: #0969da;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 5px solid #57606a;
            }
            
            /* 表格样式 */
            QTableWidget {
                background-color: #ffffff;
                border: 1px solid #d0d7de;
                border-radius: 6px;
                gridline-color: #d0d7de;
                alternate-background-color: #f6f8fa;
            }
            QTableWidget::item {
                padding: 8px;
                border: none;
                text-align: center;
                color: #24292f;
            }
            QTableWidget::item:selected {
                background-color: #0969da;
                color: #ffffff;
            }
            QHeaderView::section {
                background-color: #f6f8fa;
                border: 1px solid #d0d7de;
                padding: 8px;
                text-align: center;
                font-weight: 600;
                color: #24292f;
            }
            QHeaderView::section:first {
                border-top-left-radius: 5px;
            }
            QHeaderView::section:last {
                border-top-right-radius: 5px;
            }
            
            /* 列表样式 */
            QListWidget {
                background-color: #ffffff;
                border: 1px solid #d0d7de;
                border-radius: 6px;
                padding: 4px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #f6f8fa;
                color: #24292f;
                border-radius: 4px;
            }
            QListWidget::item:selected {
                background-color: #0969da;
                color: #ffffff;
            }
            QListWidget::item:hover {
                background-color: #f6f8fa;
            }
            
            /* 表格中的按钮 */
            QTableWidget QPushButton {
                padding: 4px 12px;
                font-size: 12px;
                min-height: 24px;
            }
        )");
    }
}

// 初始化房间列表表格
void LobbyWidget::initRoomTable()
{
    ui->roomTableWidget->setColumnCount(4);
    ui->roomTableWidget->setHorizontalHeaderLabels({"房间号", "对局状态", "玩家", "操作"});
    ui->roomTableWidget->verticalHeader()->setVisible(false);

    // 示例数据
    QStringList roomData = {
        "#001", "空闲", "等待玩家加入",
        "#002", "对战中", "张三 vs 李四",
        "#003", "空闲", "王五 (等待对手)"};

    for (int i = 0; i < roomData.size() / 3; i++)
    {
        ui->roomTableWidget->insertRow(i);
        ui->roomTableWidget->setItem(i, 0, new QTableWidgetItem(roomData[i * 3]));
        ui->roomTableWidget->setItem(i, 1, new QTableWidgetItem(roomData[i * 3 + 1]));
        ui->roomTableWidget->setItem(i, 2, new QTableWidgetItem(roomData[i * 3 + 2]));

        QPushButton *btnJoin = new QPushButton("加入");
        ui->roomTableWidget->setCellWidget(i, 3, btnJoin);

        // 对战中房间禁用加入按钮
        if (roomData[i * 3 + 1] == "对战中")
        {
            btnJoin->setEnabled(false);
        }

        connect(btnJoin, &QPushButton::clicked, this, &LobbyWidget::startOnlineGame);
    }
}

// 初始化在线玩家列表
void LobbyWidget::initPlayerList()
{
    QStringList playerData = {
        "玩家1 (在线)",
        "玩家2 (忙碌)",
        "玩家3 (在线)",
        "玩家4 (离线)",
        "玩家5 (在线)"};
    ui->playerListWidget->addItems(playerData);

    for (int i = 0; i < ui->playerListWidget->count(); i++)
    {
        QListWidgetItem *item = ui->playerListWidget->item(i);
        if (item->text().contains("在线"))
        {
            item->setForeground(QColor("#1a7f37")); // GitHub绿色
        }
        else if (item->text().contains("忙碌"))
        {
            item->setForeground(QColor("#d1242f")); // GitHub红色
        }
        else if (item->text().contains("离线"))
        {
            item->setForeground(QColor("#8c959f")); // GitHub灰色
        }
    }
}

// 可选：窗口大小变化时强制刷新表格（确保自适应生效）
void LobbyWidget::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    // m_roomTable->resize(m_roomTable->parentWidget()->width() - m_playerList->width() - 1, m_roomTable->height());
}
