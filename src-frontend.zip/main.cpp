#include "MainWindow.h"
#include <QApplication>
#include <QFile>
#include <QTextStream>

void loadStyleSheet(const QString &sheetName)
{
    QFile file(sheetName);
    if (file.open(QFile::ReadOnly))
    {
        QString styleSheet = QLatin1String(file.readAll());
        qApp->setStyleSheet(styleSheet); // qApp 是指向当前 QApplication 的全局指针
        file.close();
    }
}
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    loadStyleSheet("style.qss");

    MainWindow w;
    w.show();

    return a.exec();
}
