#include "MainWindow.h"
#include <QVBoxLayout>
#include <QStatusBar>
#include <QMessageBox>
#include <QInputDialog>
#include <QDebug>
#include <QMouseEvent>
#include <QApplication>
#include <QStyle>
#include <QLinearGradient>
#include <QPainter>
#include <QTimer>
#include "Logger.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),
                                          titleBarWidget(nullptr),
                                          titleLabel(nullptr),
                                          minimizeButton(nullptr),
                                          maximizeButton(nullptr),
                                          closeButton(nullptr),
                                          statusBarWidget(nullptr),
                                          statusMessageLabel(nullptr),
                                          networkStatusLabel(nullptr),
                                          userInfoLabel(nullptr),
                                          stackedWidget(nullptr),
                                          lobby(nullptr),
                                          game(nullptr),
                                          networkConnected(false),
                                          currentUsername(""),
                                          currentRating(1500),
                                          maximized(false)
{
    Logger::init("logs/gomoku.log", LogLevel::DEBUG, true);

    // 初始化 Manager 与 Widget
    manager = std::make_unique<Manager>();
    lobby = new LobbyWidget(this);
    game = new GameWidget(this);

    // 连接信号与槽
    connect(manager.get(), &Manager::onSwitchWidget, this, &MainWindow::onSwitchWidget);

    // 添加 Widget 到 StackedWidget中
    stackedWidget = new QStackedWidget(this);
    stackedWidget->addWidget(lobby); // Index 0: Lobby
    stackedWidget->addWidget(game);  // Index 1: Game
    stackedWidget->setCurrentIndex(0);

    // 初始化样式
    initTitleBar();
    initStatusBar();
    initStyle();
    initLayout();
    setStatusMessage("准备就绪");

    manager->connectToServer();
}

MainWindow::~MainWindow()
{
    LOG_INFO("MainWindow destructor called");
    if (manager)
    {
        manager->disconnectFromServer();
    }
}

void MainWindow::onSwitchWidget(int index)
{
    stackedWidget->setCurrentIndex(index);
    switch (index)
    {
    case 0:
        updateWindowTitle("五子棋大厅");
        statusBar()->showMessage("已返回大厅");
        break;
    case 1:
        updateWindowTitle("五子棋对战");
        statusBar()->showMessage("已进入房间");
        break;
    default:
        break;
    }
}

void MainWindow::initStyle()
{
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint | Qt::WindowMinimizeButtonHint);
    setAttribute(Qt::WA_TranslucentBackground);

    // 允许任务栏点击最小化
    setWindowFlags(windowFlags() | Qt::Window);

    this->resize(1000, 700);
}

void MainWindow::initTitleBar()
{
    // 创建标题栏部件 - GitHub Light风格
    titleBarWidget = new QWidget(this);
    titleBarWidget->setObjectName("titleBarWidget");
    titleBarWidget->setFixedHeight(40);
    // 创建标题栏布局
    QHBoxLayout *titleBarLayout = new QHBoxLayout(titleBarWidget);
    titleBarLayout->setContentsMargins(0, 0, 0, 0);
    titleBarLayout->setSpacing(0);

    // 创建标题标签
    titleLabel = new QLabel("五子棋大厅", titleBarWidget);
    titleBarLayout->addWidget(titleLabel);
    titleBarLayout->addStretch();

    // 创建窗口控制按钮
    minimizeButton = new QPushButton("─", titleBarWidget);
    maximizeButton = new QPushButton("□", titleBarWidget);
    closeButton = new QPushButton("×", titleBarWidget);

    // 设置按钮对象名用于样式表
    closeButton->setObjectName("closeButton");

    // 连接按钮信号
    connect(minimizeButton, &QPushButton::clicked, this, &MainWindow::showMinimized);
    connect(maximizeButton, &QPushButton::clicked, this, [this]()
            {
        if (maximized) {
            showNormal();
            maximizeButton->setText("□");
            maximized = false;
        } else {
            showMaximized();
            maximizeButton->setText("❐");
            maximized = true;
        } });
    connect(closeButton, &QPushButton::clicked, this, &MainWindow::close);

    // 添加按钮到布局
    titleBarLayout->addWidget(minimizeButton);
    titleBarLayout->addWidget(maximizeButton);
    titleBarLayout->addWidget(closeButton);
}

void MainWindow::initStatusBar()
{
    // 创建自定义状态栏部件
    statusBarWidget = new QWidget(this);
    statusBarWidget->setObjectName("statusBarWidget");
    statusBarWidget->setFixedHeight(30);

    // 创建状态栏布局
    QHBoxLayout *statusBarLayout = new QHBoxLayout(statusBarWidget);
    statusBarLayout->setContentsMargins(10, 0, 10, 0);
    statusBarLayout->setSpacing(15);

    // 状态消息标签
    statusMessageLabel = new QLabel("准备就绪", statusBarWidget);
    statusMessageLabel->setObjectName("statusMessageLabel");
    statusBarLayout->addWidget(statusMessageLabel);
    statusBarLayout->addStretch();

    // 网络状态标签
    networkStatusLabel = new QLabel("● 离线", statusBarWidget);
    networkStatusLabel->setObjectName("networkStatusLabel");
    statusBarLayout->addWidget(networkStatusLabel);

    // 用户信息标签
    userInfoLabel = new QLabel("游客 | 等级分: 1500", statusBarWidget);
    userInfoLabel->setObjectName("userInfoLabel");
    statusBarLayout->addWidget(userInfoLabel);
}

void MainWindow::setStatusMessage(const QString &message)
{
    if (statusMessageLabel)
    {
        statusMessageLabel->setText(message);
    }
}

void MainWindow::setNetworkStatus(bool connected)
{
    if (networkStatusLabel)
    {
        if (connected)
        {
            networkStatusLabel->setText("● 在线");
            networkStatusLabel->setStyleSheet("color: #1a7f37;"); // 绿色
        }
        else
        {
            networkStatusLabel->setText("● 离线");
            networkStatusLabel->setStyleSheet("color: #cf222e;"); // 红色
        }
    }
    networkConnected = connected;
}

void MainWindow::setUserInfo(const QString &username, int rating)
{
    currentUsername = username;
    currentRating = rating;
    if (userInfoLabel)
    {
        if (username.isEmpty())
        {
            userInfoLabel->setText(QString("游客 | 等级分: %1").arg(rating));
        }
        else
        {
            userInfoLabel->setText(QString("%1 | 等级分: %2").arg(username).arg(rating));
        }
    }
}

void MainWindow::initLayout()
{
    // 1. 创建主布局
    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    mainLayout->addWidget(titleBarWidget);
    mainLayout->addWidget(stackedWidget, 1);
    mainLayout->addWidget(statusBarWidget);

    // 2. 创建中央容器
    QWidget *centralContainer = new QWidget();
    centralContainer->setObjectName("centralContainer");
    centralContainer->setLayout(mainLayout);

    // 【核心修复 1】：必须设置此属性，否则在透明窗口下 QSS 背景色不显示
    centralContainer->setAttribute(Qt::WA_StyledBackground, true);

    // 【核心修复 2】：确保该容器充满且是 QSS 选择器的目标
    setCentralWidget(centralContainer);
}

void MainWindow::updateWindowTitle(const QString &title)
{
    titleLabel->setText(title);
    QMainWindow::setWindowTitle(title);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        // 只要点击位置在标题栏高度（40px）范围内，且不是点击在按钮上
        if (event->position().y() < titleBarWidget->height())
        {
            dragPosition = event->globalPosition().toPoint() - frameGeometry().topLeft();
            event->accept();
            return;
        }
    }
    QMainWindow::mousePressEvent(event);
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
    {
        if (!dragPosition.isNull())
        {
            move(event->globalPosition().toPoint() - dragPosition);
            event->accept();
        }
    }
    QMainWindow::mouseMoveEvent(event);
}

void MainWindow::mouseDoubleClickEvent(QMouseEvent *event)
{
    if (titleBarWidget && titleBarWidget->geometry().contains(event->pos()))
    {
        if (maximized)
        {
            showNormal();
            maximizeButton->setText("□");
            maximized = false;
        }
        else
        {
            showMaximized();
            maximizeButton->setText("❐");
            maximized = true;
        }
        event->accept();
        return;
    }
    QMainWindow::mouseDoubleClickEvent(event);
}
