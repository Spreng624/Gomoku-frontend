#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QTabWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QListWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTimer>
#include "Game.h"
#include "ChessBoardWidget.h" // 包含新的棋盘部件

class Manager; // 前向声明

class GameWidget : public QWidget
{
    Q_OBJECT

public:
    explicit GameWidget(QWidget *parent = nullptr);
    void resetGame(); // 重置游戏
    void setPlayerInfo(const QString &player1Name, int player1Score,
                       const QString &player2Name, int player2Score);
    void setGameMode(bool isPvP); // true=人人对战，false=人机对战

signals:
    void backToLobby(); // 返回大厅信号

private slots:
    void onSurrenderClicked();               // 认输按钮点击
    void onUndoClicked();                    // 悔棋按钮点击
    void onSendMessage();                    // 发送聊天消息
    void onTimerUpdate();                    // 计时器更新
    void onChessBoardMoveMade(int x, int y); // 处理棋盘落子

private:
    // 游戏逻辑
    Game game;
    bool currentPlayer; // true=黑棋(玩家1)，false=白棋(玩家2)
    bool gameStarted;
    bool isGameOver;
    QString winner;

    // 计时器
    QTimer *gameTimer;
    int player1Time; // 玩家1剩余时间（秒）
    int player2Time; // 玩家2剩余时间（秒）

    // UI组件 - 左侧棋盘区域
    ChessBoardWidget *chessBoardWidget; // 改为自定义棋盘部件

    // UI组件 - 右侧面板
    QWidget *rightPanel;

    // 顶部信息栏
    QLabel *gameIdLabel;
    QLabel *timeRuleLabel;

    // 玩家信息区域
    QWidget *player1Widget;
    QLabel *player1NameLabel;
    QLabel *player1ScoreLabel;
    QLabel *player1TimeLabel;
    QPushButton *player1Avatar;

    QWidget *player2Widget;
    QLabel *player2NameLabel;
    QLabel *player2ScoreLabel;
    QLabel *player2TimeLabel;
    QPushButton *player2Avatar;

    // 控制按钮
    QPushButton *surrenderButton;
    QPushButton *undoButton;

    // 选项卡区域
    QTabWidget *tabWidget;

    // 聊天页
    QWidget *chatTab;
    QTextEdit *chatHistory;
    QLineEdit *messageInput;
    QPushButton *sendButton;

    // 记录页
    QWidget *recordTab;
    QListWidget *moveList;

    // 玩家页
    QWidget *playerTab;
    QListWidget *onlinePlayers;

    // 设置页
    QWidget *settingTab;
    QPushButton *soundToggle;
    QPushButton *bgmToggle;
    QPushButton *autoSaveToggle;

    // 底部按钮
    QPushButton *backToLobbyButton;
    QPushButton *restartButton;

    // 私有方法
    void initUI();
    void initConnections();
    void switchPlayer();
    void updateGameStatus();
    void showWinDialog(const QString &winner);
    void addMoveRecord(int row, int col, bool isBlack);
    void addChatMessage(const QString &player, const QString &message);
};

#endif // GAMEWIDGET_H
